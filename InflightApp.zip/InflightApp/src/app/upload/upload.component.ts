import { Component, OnInit } from '@angular/core';
import {
  FormBuilder,
  FormGroup,
  FormControl,
  Validators
} from '@angular/forms';
import { UploadService } from './upload.service';

@Component({
  selector: 'app-upload-form',
  templateUrl: './upload1.component.html',
  styleUrls: ['./upload.component.css']
})
export class UploadComponent implements OnInit {
  uploadForm: FormGroup;
  constructor(
    private formBuiler: FormBuilder,
    private uploadService: UploadService
  ) {}
  isCatSelected = false;
  selectedCat = '';
  cat = '';
  tags = '';

  ngOnInit() {
    this.uploadForm = this.formBuiler.group({
      profile: ['', Validators.required]
    });
  }

  onFileSelect(event) {
    if (event.target.files.length > 0) {
      const file = event.target.files[0];
      this.uploadForm.get('profile').setValue(file);
    }
  }
  submitForm(e) {
    e.preventDefault();
    const formData = new FormData();
    formData.append('file', this.uploadForm.get('profile').value);
    console.log(this.cat, this.tags);
    console.log(formData.get('file'));
    this.uploadService.uploadData(this.cat, this.tags, formData).subscribe(
      data => {
        console.log(data);
        this.uploadService.refreshDB().subscribe(
          _ => {},
          _ => {}
        );
      },
      err => {
        console.log(err);
      }
    );
  }
}
