import { Component, OnInit } from '@angular/core';
import { MusicService } from './music.service';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';

@Component({
  selector: 'app-music',
  templateUrl: './music.component.html',
  styleUrls: ['./music.component.css']
})

export class MusicComponent implements OnInit {
  musicList: any[];
  searchText;
  selectedMusic: any;
  updatedMusicName: string;
  updatedTags: string;
  constructor(private musicService: MusicService) {}

  ngOnInit() {
    this.getMusicList();
    this.selectedMusic = this.musicList[0];
  }

  getMusicList(): void {
    this.musicService.getMusicList()
            .subscribe(data => {
                this.musicList = data['Items'].map(x => {
                  return {
                    musicName: x.Name,
                    Id: x.Id,
                    thumbnailUrl: 'http://192.168.1.6:8096/emby/Items/' + x.Id + '/Images/Primary?maxHeight=324&tag='
                    + x.ImageTags.Primary + 'quality=90'
                  };
                });
            });
  }

  edit(musicId): void {
    console.log(musicId);
    this.selectedMusic = this.musicList[musicId];
    this.updatedTags = this.selectedMusic.tags;
    this.updatedMusicName = this.selectedMusic.musicName;
  }

  updateShow(musicId): void {
    this.musicList[musicId].enabled = !this.musicList[musicId].enabled;
  }

  submitUpdateForm(e): void {
    e.preventDefault();
    this.musicList[this.selectedMusic.mid - 1].musicName = this.updatedMusicName;
    this.musicList[this.selectedMusic.mid - 1].tags = this.updatedTags;
  }
}

