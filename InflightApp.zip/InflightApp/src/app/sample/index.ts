﻿export * from './sample.component';
